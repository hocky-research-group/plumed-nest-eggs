#!/bin/bash
plumed --no-mpi pesmd < v-shape.pesmd.input
