#!/bin/bash
gmx_plumed mdrun -ntomp 1 -s ala10.tpr -deffnm ala10_fisst_-10pN_10pN -nsteps 10000 -plumed ala10.plumed.dat
