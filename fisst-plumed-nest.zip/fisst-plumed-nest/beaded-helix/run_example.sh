#!/bin/bash
lmp_plumed -log helix_fisst_example.log \
           -var plumed_file helix_fisst_fmin-2.0_fmax8.0_eps7.5_10000000.plumed.dat \
           -var outprefix helix_fisst_example \
           -var steps 10000  \
           -var eps 7.5 \
           -in run_helix_plumed.lmp 

#note, pulling using RESTRAINT has opposite sign of forces to FISST. This is pulling out by F=4.5
lmp_plumed -log helix_sf_example.log \
           -var plumed_file helix_sf_f-4.5_eps7.5_10000000.plumed.dat  \
           -var outprefix helix_sf_example \
           -var steps 10000  \
           -var eps 7.5 \
           -in run_helix_plumed.lmp 
